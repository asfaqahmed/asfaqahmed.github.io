const ScrollbarProgressModule = () => {
    return (
        <>
        {/* scrollbar progress */}
        <div className="mil-progress-track">
            <div className="mil-progress" />
        </div>
        {/* scrollbar progress end */}
        </>
    );
};
export default ScrollbarProgressModule;