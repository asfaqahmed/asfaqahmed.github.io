---
#preview
title: Design
introTitle: Publications <br>Category <span class=\"mil-thin\">Design</span>
---