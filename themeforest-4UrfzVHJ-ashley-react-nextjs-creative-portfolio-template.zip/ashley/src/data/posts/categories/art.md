---
#preview
title: Art
introTitle: Publications <br>Category <span class=\"mil-thin\">Art</span>
---